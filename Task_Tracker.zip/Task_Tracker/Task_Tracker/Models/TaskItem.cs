﻿namespace Task_Tracker.Models
{
    public class TaskItem
    {
        public  string Title { get; set; }
        public  DateTime StartDate { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsCompleted { get; set; }
    }
}
